# GOOOL Athletics Circular Center Crewneck — Gray Heather

**Revision 2: local artwork and placement package prepared; supplier proof/sample not approved.**

Blank: AS Colour 5150 Made Crew. Exact supplier color candidate: Athletic Heather. Sizes: S, M, L, XL, XXL.

Recorded design ID: not created. Reopen and verify it; do not assume old records include the new label.

See [PLACEMENT-PROOF.html](PLACEMENT-PROOF.html) for front/back views and measurements. The diagrams are technical layouts, not verified garment pattern drawings. Physical dimensions govern; silhouettes are illustrative.

## Decoration specification

| Face | Visible width x height (in) | Vertical anchor / offset | Horizontal position | Artwork |
|---|---|---|---|---|
| front | 2.500 x 2.527 | 3.500: top of visible artwork below bottom front collar seam | body centerline | [GA-CIRCLE-09-FOREST-PRINT.svg](artwork/GA-CIRCLE-09-FOREST-PRINT.svg) |

Method: DTF / transfer; supplier process confirmation required. Back: blank. Sleeves blank; cap sides/rear blank. Preserve aspect ratio and exact three-O spelling. Dimensions apply to visible artwork. Existing PNG transparent insets are recorded in spec.json; new circular artwork is tightly bounded.

## Label

Flat one-inch SVG and PNG now supplied in label/artwork/. Read label/README.md for color-capable service, actual small-text size and woven limitations. Two-inch variant is a comparison alternative only. Verify the service, garment-specific interior position and attachment proof.

## Customer release requirements

- Fresh account verification required for exact blank, color, offered sizes, decoration placement and saved design IDs/SKUs.
- Supplier production proof/sample approval and existing release checks remain required; package readiness does not authorize manufacturing or sales.
- Label artwork is prepared; select a compatible service, verify small-detail legibility and inside placement, obtain supply ID and production proof before applying. One-inch woven layout is not automatically viable.
- Verify newly authored collar/center offsets and original non-square aspect ratio on all offered sizes. SVG outline edge and color proof required.

Complete verification-record.json for every offered size and SAMPLE-ACCEPTANCE.json from actual sample evidence. No blank, color or print-process substitution without a recorded decision. Reconcile customer photos with the verified garment before launch. No sales/fulfillment activation or paid orders from this package.

Read [SAVED-DESIGN-UPDATES.md](SAVED-DESIGN-UPDATES.md): newer supplier IDs were incorporated during final verification. The performance 11in versus 9in target and circular canvas-versus-visible-size differences require correction/proof.
